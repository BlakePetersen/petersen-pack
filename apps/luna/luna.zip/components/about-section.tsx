import Image from "next/image"

export function AboutSection() {
  return (
    <section className="py-24 px-6 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative aspect-[3/4] bg-muted overflow-hidden">
            <Image
              src="/elegant-portrait-photography-natural-light.jpg"
              alt="Photographer portrait"
              fill
              className="object-cover"
            />
          </div>
          <div>
            <h2 className="font-serif text-5xl md:text-6xl mb-6 text-foreground">About Luna</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                With over a decade of experience capturing moments that matter, I specialize in creating timeless
                imagery that tells your unique story.
              </p>
              <p>
                My approach combines technical precision with artistic vision, resulting in photographs that are both
                beautiful and authentic. Whether it's an intimate portrait session or a grand editorial project, I bring
                the same level of dedication and creativity to every shoot.
              </p>
              <p>
                Based in the heart of the city, I work with clients worldwide, bringing a refined aesthetic and
                professional expertise to every project.
              </p>
            </div>
            <div className="mt-8 grid grid-cols-3 gap-8">
              <div>
                <p className="font-serif text-4xl text-foreground">10+</p>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Years Experience</p>
              </div>
              <div>
                <p className="font-serif text-4xl text-foreground">500+</p>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Projects Completed</p>
              </div>
              <div>
                <p className="font-serif text-4xl text-foreground">50+</p>
                <p className="text-sm text-muted-foreground uppercase tracking-wider">Awards Won</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
