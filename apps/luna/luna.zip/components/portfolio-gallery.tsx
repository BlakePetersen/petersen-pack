"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"

const portfolioCategories = ["All", "Portrait", "Landscape", "Editorial", "Architecture"]

const portfolioImages = [
  {
    src: "/elegant-portrait-photography-natural-light.jpg",
    category: "Portrait",
    title: "Natural Light Portrait",
  },
  {
    src: "/minimalist-architectural-photography-modern-buildi.jpg",
    category: "Architecture",
    title: "Modern Architecture",
  },
  {
    src: "/dramatic-landscape-photography-golden-hour.jpg",
    category: "Landscape",
    title: "Golden Hour",
  },
  {
    src: "/editorial-fashion-photography-black-and-white.jpg",
    category: "Editorial",
    title: "Editorial Fashion",
  },
  {
    src: "/elegant-portrait-photography-natural-light.jpg",
    category: "Portrait",
    title: "Studio Portrait",
  },
  {
    src: "/dramatic-landscape-photography-golden-hour.jpg",
    category: "Landscape",
    title: "Mountain Vista",
  },
]

export function PortfolioGallery() {
  const [activeCategory, setActiveCategory] = useState("All")

  const filteredImages =
    activeCategory === "All" ? portfolioImages : portfolioImages.filter((img) => img.category === activeCategory)

  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-5xl md:text-6xl mb-4 text-foreground">Featured Work</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A curated selection of recent projects showcasing diverse styles and subjects
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {portfolioCategories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              onClick={() => setActiveCategory(category)}
              className="uppercase tracking-wider text-xs"
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredImages.map((image, index) => (
            <div key={index} className="group relative aspect-[4/5] overflow-hidden bg-muted cursor-pointer">
              <Image
                src={image.src || "/placeholder.svg"}
                alt={image.title}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-500 flex items-end p-6">
                <div className="translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                  <p className="text-white font-serif text-xl">{image.title}</p>
                  <p className="text-white/80 text-sm uppercase tracking-wider">{image.category}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="uppercase tracking-wider bg-transparent">
            View Full Portfolio
          </Button>
        </div>
      </div>
    </section>
  )
}
