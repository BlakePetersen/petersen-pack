import { Mail, Phone, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export function ContactSection() {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-5xl md:text-6xl mb-4 text-foreground">Get In Touch</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Let's discuss your project and bring your vision to life
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="font-serif text-3xl mb-6 text-foreground">Contact Information</h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <Mail className="w-5 h-5 text-foreground mt-1" strokeWidth={1.5} />
                <div>
                  <p className="text-foreground font-medium">Email</p>
                  <p className="text-muted-foreground">hello@lunaphotography.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Phone className="w-5 h-5 text-foreground mt-1" strokeWidth={1.5} />
                <div>
                  <p className="text-foreground font-medium">Phone</p>
                  <p className="text-muted-foreground">+1 (555) 123-4567</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-foreground mt-1" strokeWidth={1.5} />
                <div>
                  <p className="text-foreground font-medium">Studio</p>
                  <p className="text-muted-foreground">
                    123 Creative Avenue
                    <br />
                    New York, NY 10001
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12">
              <p className="text-muted-foreground mb-4">Follow the journey</p>
              <div className="flex gap-4">
                <Button variant="outline" size="icon">
                  <span className="sr-only">Instagram</span>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z"
                      clipRule="evenodd"
                    />
                  </svg>
                </Button>
                <Button variant="outline" size="icon">
                  <span className="sr-only">Pinterest</span>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 0a12 12 0 00-4.37 23.17c-.06-.55-.12-1.39.03-1.99.13-.54.85-3.61.85-3.61s-.22-.43-.22-1.07c0-1-.58-1.75-1.3-1.75-.62 0-.92.46-.92 1.02 0 .62.4 1.55.6 2.41.17.73.75 1.23 1.41 1.23 1.7 0 3-1.79 3-4.38 0-2.29-1.65-3.89-4-3.89-2.73 0-4.33 2.05-4.33 4.17 0 .83.31 1.71.71 2.19.08.09.09.17.06.27l-.26 1.06c-.04.17-.14.21-.32.13-1.19-.55-1.93-2.29-1.93-3.68 0-3.01 2.19-5.77 6.31-5.77 3.31 0 5.89 2.36 5.89 5.52 0 3.29-2.07 5.94-4.95 5.94-.97 0-1.88-.5-2.19-1.09l-.6 2.27c-.21.82-.79 1.85-1.18 2.48A12 12 0 1012 0z" />
                  </svg>
                </Button>
              </div>
            </div>
          </div>

          <div>
            <form className="space-y-6">
              <div>
                <Input placeholder="Your Name" className="bg-background" />
              </div>
              <div>
                <Input type="email" placeholder="Email Address" className="bg-background" />
              </div>
              <div>
                <Input placeholder="Project Type" className="bg-background" />
              </div>
              <div>
                <Textarea placeholder="Tell me about your project..." rows={6} className="bg-background resize-none" />
              </div>
              <Button size="lg" className="w-full uppercase tracking-wider">
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
