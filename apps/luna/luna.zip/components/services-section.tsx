import { Camera, Users, Building2, Sparkles } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const services = [
  {
    icon: Camera,
    title: "Portrait Photography",
    description:
      "Capturing the essence of individuals and families with natural, timeless portraits that celebrate personality and connection.",
  },
  {
    icon: Users,
    title: "Editorial & Fashion",
    description:
      "High-end editorial work for magazines, brands, and creative projects that demand striking visual storytelling.",
  },
  {
    icon: Building2,
    title: "Architectural",
    description:
      "Showcasing spaces and structures with precision and artistry, highlighting design details and spatial relationships.",
  },
  {
    icon: Sparkles,
    title: "Commercial Projects",
    description:
      "Professional imagery for businesses, products, and marketing campaigns that elevate your brand presence.",
  },
]

export function ServicesSection() {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-5xl md:text-6xl mb-4 text-foreground">Services</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Comprehensive photography services tailored to your vision and needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="border-border hover:border-foreground/20 transition-colors duration-300">
              <CardContent className="p-8">
                <service.icon className="w-10 h-10 mb-6 text-foreground" strokeWidth={1.5} />
                <h3 className="font-serif text-2xl mb-3 text-foreground">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed text-sm">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
