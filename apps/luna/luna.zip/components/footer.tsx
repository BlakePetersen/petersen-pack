export function Footer() {
  return (
    <footer className="py-12 px-6 bg-muted/30 border-t border-border">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <p className="font-serif text-2xl text-foreground">Luna</p>
            <p className="text-muted-foreground text-sm mt-1">Professional Photography</p>
          </div>
          <div className="flex gap-8 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">
              Portfolio
            </a>
            <a href="#" className="hover:text-foreground transition-colors">
              About
            </a>
            <a href="#" className="hover:text-foreground transition-colors">
              Services
            </a>
            <a href="#" className="hover:text-foreground transition-colors">
              Contact
            </a>
          </div>
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} Luna Photography. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
