"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const testimonials = [
  {
    quote:
      "Luna's ability to capture emotion and authenticity is unparalleled. The portraits from our session are treasured family heirlooms.",
    author: "Sarah Mitchell",
    role: "Private Client",
  },
  {
    quote:
      "Working with Luna elevated our brand imagery to a new level. Professional, creative, and an absolute pleasure to collaborate with.",
    author: "James Chen",
    role: "Creative Director, Atelier Studio",
  },
  {
    quote:
      "The editorial work exceeded all expectations. Luna has an incredible eye for composition and storytelling through imagery.",
    author: "Emma Rodriguez",
    role: "Editor-in-Chief, Vogue",
  },
]

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    const interval = setInterval(nextTestimonial, 6000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="py-24 px-6 bg-muted/30">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-5xl md:text-6xl mb-4 text-foreground">Client Testimonials</h2>
        </div>

        <div className="relative">
          <div className="text-center px-12">
            <p className="font-serif text-2xl md:text-3xl mb-8 text-foreground leading-relaxed italic">
              "{testimonials[currentIndex].quote}"
            </p>
            <div>
              <p className="text-foreground font-medium">{testimonials[currentIndex].author}</p>
              <p className="text-muted-foreground text-sm uppercase tracking-wider">
                {testimonials[currentIndex].role}
              </p>
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={prevTestimonial}
            className="absolute left-0 top-1/2 -translate-y-1/2"
          >
            <ChevronLeft className="w-6 h-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={nextTestimonial}
            className="absolute right-0 top-1/2 -translate-y-1/2"
          >
            <ChevronRight className="w-6 h-6" />
          </Button>

          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex ? "bg-foreground w-8" : "bg-border"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
