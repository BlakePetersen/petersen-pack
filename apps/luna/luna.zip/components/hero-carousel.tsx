"use client"

import { useState, useEffect, useCallback } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface CarouselSlide {
  id: number
  image: string
  title: string
  subtitle: string
  category: string
}

const slides: CarouselSlide[] = [
  {
    id: 1,
    image: "/elegant-portrait-photography-natural-light.jpg",
    title: "Timeless Portraits",
    subtitle: "Capturing the essence of human connection",
    category: "Portrait",
  },
  {
    id: 2,
    image: "/minimalist-architectural-photography-modern-buildi.jpg",
    title: "Architectural Vision",
    subtitle: "Where structure meets artistry",
    category: "Architecture",
  },
  {
    id: 3,
    image: "/dramatic-landscape-photography-golden-hour.jpg",
    title: "Natural Beauty",
    subtitle: "The world through a refined lens",
    category: "Landscape",
  },
  {
    id: 4,
    image: "/editorial-fashion-photography-black-and-white.jpg",
    title: "Editorial Excellence",
    subtitle: "Fashion meets fine art",
    category: "Editorial",
  },
]

export function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const [direction, setDirection] = useState<"next" | "prev">("next")

  const nextSlide = useCallback(() => {
    setDirection("next")
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }, [])

  const prevSlide = useCallback(() => {
    setDirection("prev")
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }, [])

  const goToSlide = (index: number) => {
    setDirection(index > currentSlide ? "next" : "prev")
    setCurrentSlide(index)
    setIsAutoPlaying(false)
  }

  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      nextSlide()
    }, 5000)

    return () => clearInterval(interval)
  }, [isAutoPlaying, nextSlide])

  return (
    <div className="relative h-screen w-full overflow-hidden bg-black">
      {/* Slides */}
      <div className="relative h-full w-full">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={cn(
              "absolute inset-0 transition-all duration-1000 ease-in-out",
              index === currentSlide
                ? "opacity-100 scale-100"
                : index === (currentSlide - 1 + slides.length) % slides.length && direction === "prev"
                  ? "opacity-0 scale-105"
                  : "opacity-0 scale-95",
            )}
          >
            <img src={slide.image || "/placeholder.svg"} alt={slide.title} className="h-full w-full object-cover" />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
          </div>
        ))}
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex items-end">
        <div className="container mx-auto px-6 pb-20 md:px-12 lg:px-16">
          <div className="max-w-3xl">
            {slides.map((slide, index) => (
              <div
                key={slide.id}
                className={cn(
                  "transition-all duration-700",
                  index === currentSlide ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8 absolute",
                )}
              >
                <div className="mb-4 inline-block">
                  <span className="text-xs font-medium tracking-[0.2em] text-white/70 uppercase">{slide.category}</span>
                </div>
                <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-light text-white mb-4 leading-[1.1] text-balance">
                  {slide.title}
                </h1>
                <p className="text-lg md:text-xl text-white/80 font-light tracking-wide max-w-xl text-pretty">
                  {slide.subtitle}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Navigation Arrows */}
      <div className="absolute inset-y-0 left-0 right-0 flex items-center justify-between px-6 md:px-12 lg:px-16 pointer-events-none">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => {
            prevSlide()
            setIsAutoPlaying(false)
          }}
          className="pointer-events-auto h-12 w-12 rounded-full border border-white/20 bg-black/20 backdrop-blur-sm text-white hover:bg-white/10 hover:border-white/40 transition-all"
          aria-label="Previous slide"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => {
            nextSlide()
            setIsAutoPlaying(false)
          }}
          className="pointer-events-auto h-12 w-12 rounded-full border border-white/20 bg-black/20 backdrop-blur-sm text-white hover:bg-white/10 hover:border-white/40 transition-all"
          aria-label="Next slide"
        >
          <ChevronRight className="h-6 w-6" />
        </Button>
      </div>

      {/* Pagination Dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={cn(
              "h-1.5 rounded-full transition-all duration-300",
              index === currentSlide ? "w-12 bg-white" : "w-1.5 bg-white/40 hover:bg-white/60",
            )}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 right-6 md:right-12 lg:right-16 flex flex-col items-center gap-2">
        <span className="text-xs text-white/60 tracking-widest uppercase rotate-90 origin-center translate-x-4">
          Scroll
        </span>
        <div className="h-12 w-px bg-white/30" />
      </div>
    </div>
  )
}
